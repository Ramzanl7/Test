const CACHE_NAME = 'kavkazlook-shell-v1';
const APP_SHELL = ['./', './index.html', './styles.css', './src/main.js', './src/data.js', './src/config.js', './src/supabase.js', './manifest.webmanifest', './assets/kavkazlook.svg'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))));
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (url.pathname.includes('/rest/v1/') || url.pathname.includes('/auth/v1/')) return;
  event.respondWith(fetch(request).then((response) => {
    if (response.ok && request.url.startsWith(self.location.origin)) {
      const copy = response.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
    }
    return response;
  }).catch(async () => (await caches.match(request)) || caches.match('./index.html')));
});
