// Local demo data. These are fictional sample listings, not real Grozny stores.
export const categories = [
  { id: 'women', name: 'Женская одежда', icon: '✦' },
  { id: 'men', name: 'Мужская одежда', icon: '◈' },
  { id: 'shoes', name: 'Обувь', icon: '⌁' },
  { id: 'bags', name: 'Сумки', icon: '▱' },
  { id: 'accessories', name: 'Аксессуары', icon: '◇' },
];

export const demoBoutiques = [
  {
    id: 'demo-shop-1', name: 'Бутик «Линия»', category: 'Женская одежда',
    description: 'Повседневная одежда и базовые образы.', city: 'Грозный',
    cover_url: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1000&q=85',
    verified: true, is_active: true,
  },
  {
    id: 'demo-shop-2', name: 'Магазин «Форма»', category: 'Мужская одежда',
    description: 'Одежда на каждый день и для особых случаев.', city: 'Грозный',
    cover_url: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1000&q=85',
    verified: true, is_active: true,
  },
  {
    id: 'demo-shop-3', name: 'Студия «Точка»', category: 'Обувь и аксессуары',
    description: 'Обувь, сумки и детали образа.', city: 'Грозный',
    cover_url: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=1000&q=85',
    verified: false, is_active: true,
  },
];

export const demoProducts = [
  {
    id: 'demo-p-1', title: 'Платье прямого кроя', category: 'women', price: 5900,
    old_price: 6900, boutique_id: 'demo-shop-1', boutique_name: 'Бутик «Линия»',
    description: 'Лаконичное платье для повседневных образов. Свободная посадка и приятная к телу ткань.',
    image_url: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=900&q=85',
    badge: 'Хит', sizes: ['S', 'M', 'L'], colors: ['#202820', '#D8C7B4'], stock: 12,
  },
  {
    id: 'demo-p-2', title: 'Жакет свободного силуэта', category: 'women', price: 8400,
    boutique_id: 'demo-shop-1', boutique_name: 'Бутик «Линия»',
    description: 'Универсальный жакет, который сочетается с джинсами, брюками и платьями.',
    image_url: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=900&q=85',
    badge: 'Новинка', sizes: ['S', 'M', 'L'], colors: ['#C8B9A6', '#222A25'], stock: 8,
  },
  {
    id: 'demo-p-3', title: 'Рубашка из хлопка', category: 'men', price: 4200,
    boutique_id: 'demo-shop-2', boutique_name: 'Магазин «Форма»',
    description: 'Хлопковая рубашка с прямым кроем. Подходит для повседневного и делового образа.',
    image_url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=900&q=85',
    sizes: ['M', 'L', 'XL'], colors: ['#E9E6DF', '#7B8C7E'], stock: 18,
  },
  {
    id: 'demo-p-4', title: 'Кроссовки City', category: 'shoes', price: 7100,
    boutique_id: 'demo-shop-3', boutique_name: 'Студия «Точка»',
    description: 'Лёгкая пара для города с мягкой стелькой и нескользящей подошвой.',
    image_url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85',
    badge: 'Популярное', sizes: ['37', '38', '39', '40', '41', '42'], colors: ['#B7B8B5', '#343B35'], stock: 10,
  },
  {
    id: 'demo-p-5', title: 'Сумка на каждый день', category: 'bags', price: 5600,
    boutique_id: 'demo-shop-3', boutique_name: 'Студия «Точка»',
    description: 'Компактная сумка с удобным отделением для самых нужных вещей.',
    image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=85',
    sizes: [], colors: ['#6E5140', '#202820'], stock: 6,
  },
  {
    id: 'demo-p-6', title: 'Базовая футболка', category: 'men', price: 1900,
    boutique_id: 'demo-shop-2', boutique_name: 'Магазин «Форма»',
    description: 'Плотный хлопок, комфортная посадка и базовые цвета.',
    image_url: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=85',
    sizes: ['S', 'M', 'L', 'XL'], colors: ['#F4F2EC', '#202820'], stock: 30,
  },
  {
    id: 'demo-p-7', title: 'Пальто прямого кроя', category: 'women', price: 12900,
    boutique_id: 'demo-shop-1', boutique_name: 'Бутик «Линия»',
    description: 'Сдержанный силуэт и универсальная длина для холодного сезона.',
    image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=900&q=85',
    badge: 'Новинка', sizes: ['S', 'M', 'L'], colors: ['#B9A48F', '#333C35'], stock: 5,
  },
  {
    id: 'demo-p-8', title: 'Кожаный ремень', category: 'accessories', price: 2400,
    boutique_id: 'demo-shop-2', boutique_name: 'Магазин «Форма»',
    description: 'Ремень с лаконичной металлической пряжкой.',
    image_url: 'https://images.unsplash.com/photo-1624222247344-550fb8a3a0e8?auto=format&fit=crop&w=900&q=85',
    sizes: [], colors: ['#30251F', '#6C4935'], stock: 14,
  },
  {
    id: 'demo-p-9', title: 'Кеды минималистичные', category: 'shoes', price: 4900,
    boutique_id: 'demo-shop-3', boutique_name: 'Студия «Точка»',
    description: 'Лаконичная модель, подходящая к базовому гардеробу.',
    image_url: 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=85',
    sizes: ['36', '37', '38', '39', '40', '41'], colors: ['#E8E7E1'], stock: 9,
  },
  {
    id: 'demo-p-10', title: 'Брюки свободного кроя', category: 'men', price: 5300,
    boutique_id: 'demo-shop-2', boutique_name: 'Магазин «Форма»',
    description: 'Прямые брюки с комфортной посадкой и аккуратной линией.',
    image_url: 'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=900&q=85',
    sizes: ['S', 'M', 'L', 'XL'], colors: ['#252D28', '#B6A995'], stock: 11,
  },
  {
    id: 'demo-p-11', title: 'Серьги геометрия', category: 'accessories', price: 1600,
    boutique_id: 'demo-shop-3', boutique_name: 'Студия «Точка»',
    description: 'Небольшие серьги лаконичной формы на каждый день.',
    image_url: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=900&q=85',
    sizes: [], colors: ['#D1B477'], stock: 20,
  },
  {
    id: 'demo-p-12', title: 'Платье вечернее', category: 'women', price: 9800,
    boutique_id: 'demo-shop-1', boutique_name: 'Бутик «Линия»',
    description: 'Сдержанное вечернее платье с выразительным силуэтом.',
    image_url: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=900&q=85',
    sizes: ['S', 'M', 'L'], colors: ['#252A26'], stock: 4,
  },
];

export function categoryName(id) {
  return categories.find((item) => item.id === id)?.name || 'Одежда';
}
