/**
 * Public browser configuration.
 * Only a Supabase project URL and publishable/anon key belong here.
 * NEVER put a service_role/secret key in this file.
 */
export const CONFIG = {
  supabaseUrl: '',
  supabaseAnonKey: '',
};

export const isSupabaseConfigured = Boolean(
  CONFIG.supabaseUrl.trim() && CONFIG.supabaseAnonKey.trim()
);
