import { CONFIG, isSupabaseConfigured } from './config.js';

let clientPromise;

export async function getSupabase() {
  if (!isSupabaseConfigured) return null;
  if (!clientPromise) {
    clientPromise = import('https://esm.sh/@supabase/supabase-js@2').then(({ createClient }) =>
      createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
          flowType: 'pkce',
        },
        global: {
          headers: { 'X-Client-Info': 'kavkazlook-web-mvp' },
        },
      })
    );
  }
  return clientPromise;
}

export { isSupabaseConfigured };
