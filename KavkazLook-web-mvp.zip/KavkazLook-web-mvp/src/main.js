import { demoBoutiques, demoProducts, categories, categoryName } from './data.js';
import { getSupabase, isSupabaseConfigured } from './supabase.js';

const root = document.querySelector('#app');
const modalRoot = document.querySelector('#modal-root');
const toastRoot = document.querySelector('#toast-root');
const STORAGE_KEY = 'kavkazlook-web-state-v1';

const safeRead = (key, fallback) => {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return value ?? fallback;
  } catch {
    return fallback;
  }
};

const stored = safeRead(STORAGE_KEY, {});
const state = {
  page: 'catalog',
  query: '',
  category: 'all',
  sort: 'recommended',
  products: [...demoProducts.map((item) => ({ ...item })), ...(Array.isArray(stored.demoAddedProducts) ? stored.demoAddedProducts : [])],
  demoAddedProducts: Array.isArray(stored.demoAddedProducts) ? stored.demoAddedProducts : [],
  boutiques: demoBoutiques.map((item) => ({ ...item })),
  cart: Array.isArray(stored.cart) ? stored.cart.filter((item) => item && (typeof item.productId === 'string' || typeof item.productId === 'number')).map((item) => ({ productId: String(item.productId), quantity: Math.max(1, Math.min(20, Math.floor(Number(item.quantity) || 1))), size: String(item.size || '').slice(0, 40) })) : [],
  favorites: Array.isArray(stored.favorites) ? stored.favorites.filter((id) => typeof id === 'string' || typeof id === 'number').map(String) : [],
  orders: Array.isArray(stored.orders) ? stored.orders.filter((item) => item && typeof item === 'object') : [],
  currentProduct: null,
  selectedSize: '',
  profile: null,
  session: null,
  demoMode: false,
  demoRole: null,
  myBoutique: null,
  sellerProducts: [],
  sellerOrders: [],
  adminData: null,
  authOpen: false,
  authStep: 'phone',
  authPhone: '+7',
  authName: '',
  authCode: '',
  authBusy: false,
  authPurpose: 'login',
  toastTimer: null,
  productBusy: false,
};

let supabase = null;
let authSubscription = null;

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      cart: state.cart,
      favorites: state.favorites,
      orders: state.orders,
      demoAddedProducts: state.demoAddedProducts,
    }));
  } catch (error) {
    console.warn('Local storage is unavailable:', error);
    showToast('Браузер не разрешил сохранить изменения', 'error');
  }
}

function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
}

function safeImage(url) {
  if (!url) return '';
  try {
    const parsed = new URL(url, window.location.href);
    return parsed.protocol === 'https:' ? escapeHtml(parsed.href) : '';
  } catch {
    return '';
  }
}

function money(value) {
  return `${Number(value || 0).toLocaleString('ru-RU')} ₽`;
}

function showToast(message, type = 'info') {
  if (!toastRoot) return;
  toastRoot.innerHTML = `<div class="toast toast-${type}" role="status">${escapeHtml(message)}</div>`;
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => { toastRoot.innerHTML = ''; }, 3200);
}

function normalizePhone(value) {
  let digits = String(value || '').replace(/\D/g, '');
  if (digits.startsWith('8') && digits.length === 11) digits = `7${digits.slice(1)}`;
  if (digits.length === 10) digits = `7${digits}`;
  return digits.length === 11 && digits.startsWith('7') ? `+${digits}` : '';
}

function formatPhone(value) {
  let digits = String(value || '').replace(/\D/g, '');
  if (!digits) return '+7';
  if (digits.startsWith('8')) digits = `7${digits.slice(1)}`;
  if (!digits.startsWith('7')) digits = `7${digits}`;
  digits = digits.slice(0, 11);
  const rest = digits.slice(1);
  if (!rest) return '+7';
  if (rest.length <= 3) return `+7 (${rest}`;
  if (rest.length <= 6) return `+7 (${rest.slice(0, 3)}) ${rest.slice(3)}`;
  if (rest.length <= 8) return `+7 (${rest.slice(0, 3)}) ${rest.slice(3, 6)}-${rest.slice(6)}`;
  return `+7 (${rest.slice(0, 3)}) ${rest.slice(3, 6)}-${rest.slice(6, 8)}-${rest.slice(8, 10)}`;
}

function getProduct(productId) {
  return state.products.find((product) => String(product.id) === String(productId))
    || demoProducts.find((product) => String(product.id) === String(productId));
}

function getBoutique(boutiqueId) {
  return state.boutiques.find((item) => String(item.id) === String(boutiqueId))
    || demoBoutiques.find((item) => String(item.id) === String(boutiqueId));
}

function cartCount() {
  return state.cart.reduce((total, item) => total + Number(item.quantity || 1), 0);
}

function cartTotal() {
  return state.cart.reduce((total, item) => {
    const product = getProduct(item.productId);
    return total + (Number(product?.price) || 0) * Number(item.quantity || 1);
  }, 0);
}

function cartItemKey(productId, size = '') {
  return encodeURIComponent(JSON.stringify([String(productId), String(size || '')]));
}

function decodeCartItemKey(key) {
  try {
    const [productId, size] = JSON.parse(decodeURIComponent(String(key || '')));
    return { productId: String(productId), size: String(size || '') };
  } catch {
    return null;
  }
}

function isFavorite(productId) {
  return state.favorites.some((id) => String(id) === String(productId));
}

function isSignedIn() {
  return Boolean(state.session || state.demoMode);
}

function currentRole() {
  return state.demoMode ? state.demoRole : state.profile?.role;
}

function saveCartItem(productId, quantity = 1) {
  const product = getProduct(productId);
  const size = product?.sizes?.[0] || '';
  const existing = state.cart.find((item) => String(item.productId) === String(productId) && String(item.size || '') === size);
  if (existing) existing.quantity = Math.min(20, Number(existing.quantity || 1) + quantity);
  else state.cart.push({ productId, quantity, size });
  persist();
  render();
  showToast('Добавлено в корзину');
}

async function toggleFavorite(productId) {
  const previous = [...state.favorites];
  const removing = isFavorite(productId);
  if (removing) {
    state.favorites = state.favorites.filter((id) => String(id) !== String(productId));
    showToast('Удалено из избранного');
  } else {
    state.favorites.push(productId);
    showToast('Добавлено в избранное');
  }
  persist();
  render();
  if (state.session && supabase && !String(productId).startsWith('demo-')) {
    try {
      if (removing) {
        const { error } = await supabase.from('favorites').delete().eq('product_id', productId).eq('user_id', state.session.user.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('favorites').insert({ product_id: productId, user_id: state.session.user.id });
        if (error && error.code !== '23505') throw error;
      }
    } catch (error) {
      state.favorites = previous;
      persist();
      render();
      showToast('Изменение не сохранено на сервере', 'error');
    }
  }
}

function categoryIcon(categoryId) {
  return categories.find((item) => item.id === categoryId)?.icon || '◇';
}

function productCard(product) {
  const image = safeImage(product.image_url || product.image);
  const badge = product.badge ? `<span class="product-badge">${escapeHtml(product.badge)}</span>` : '';
  const favorite = isFavorite(product.id);
  return `
    <article class="product-card">
      <div class="product-image-wrap">
        <button class="product-image-button" type="button" data-action="open-product" data-id="${escapeHtml(product.id)}" aria-label="Открыть ${escapeHtml(product.title)}">
          ${image ? `<img class="product-image" src="${image}" alt="${escapeHtml(product.title)}" loading="lazy">` : '<span class="product-image-placeholder">K</span>'}
        </button>
        ${badge}
        <button class="favorite-button ${favorite ? 'is-active' : ''}" type="button" data-action="favorite" data-id="${escapeHtml(product.id)}" aria-label="${favorite ? 'Убрать из избранного' : 'В избранное'}">${favorite ? '♥' : '♡'}</button>
      </div>
      <div class="product-info">
        <div class="product-store">${escapeHtml(product.boutique_name || getBoutique(product.boutique_id)?.name || 'Магазин')}</div>
        <h3><button class="product-title-button" type="button" data-action="open-product" data-id="${escapeHtml(product.id)}">${escapeHtml(product.title)}</button></h3>
        <div class="product-price-row"><strong>${money(product.price)}</strong>${product.old_price ? `<del>${money(product.old_price)}</del>` : ''}</div>
        <button class="add-button" type="button" data-action="add" data-id="${escapeHtml(product.id)}">В корзину <span>+</span></button>
      </div>
    </article>`;
}

function categoryPills() {
  const all = [{ id: 'all', name: 'Все товары', icon: '⌂' }, ...categories];
  return all.map((item) => `
    <button class="category-pill ${state.category === item.id ? 'is-selected' : ''}" data-action="category" data-id="${item.id}" type="button">
      <span>${item.icon}</span>${escapeHtml(item.name)}
    </button>`).join('');
}

function filteredProducts() {
  let products = [...state.products];
  if (state.category !== 'all') products = products.filter((product) => product.category === state.category);
  const query = state.query.trim().toLocaleLowerCase('ru-RU');
  if (query) {
    products = products.filter((product) => [
      product.title, product.description, product.boutique_name, categoryName(product.category),
    ].filter(Boolean).join(' ').toLocaleLowerCase('ru-RU').includes(query));
  }
  if (state.sort === 'price-up') products.sort((a, b) => Number(a.price) - Number(b.price));
  if (state.sort === 'price-down') products.sort((a, b) => Number(b.price) - Number(a.price));
  if (state.sort === 'new') products.sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
  return products;
}

function header() {
  const role = currentRole();
  return `
    <header class="site-header">
      <div class="header-inner">
        <button class="brand" data-action="navigate" data-page="catalog" aria-label="Kavkaz Look — каталог">
          <span class="brand-mark">KL</span>
          <span class="brand-copy"><b>Kavkaz Look</b><small>Одежда и магазины</small></span>
        </button>
        <nav class="desktop-nav" aria-label="Основная навигация">
          <button class="nav-link ${state.page === 'catalog' ? 'active' : ''}" data-action="navigate" data-page="catalog">Каталог</button>
          <button class="nav-link ${state.page === 'boutiques' ? 'active' : ''}" data-action="navigate" data-page="boutiques">Магазины</button>
          <button class="nav-link ${state.page === 'favorites' ? 'active' : ''}" data-action="navigate" data-page="favorites">Избранное</button>
        </nav>
        <label class="header-search"><span>⌕</span><input id="header-search-input" type="search" value="${escapeHtml(state.query)}" placeholder="Поиск товаров и магазинов" autocomplete="off"><kbd>⌘ K</kbd></label>
        <div class="header-actions">
          <button class="icon-button desktop-only" data-action="navigate" data-page="favorites" aria-label="Избранное">♡</button>
          <button class="cart-button" data-action="navigate" data-page="cart" aria-label="Корзина"><span>Корзина</span><b>${cartCount()}</b></button>
          <button class="profile-button" data-action="navigate" data-page="profile" aria-label="Профиль">${isSignedIn() ? escapeHtml((state.profile?.full_name || (state.demoRole === 'seller' ? 'Продавец' : 'Вы')).slice(0, 1).toUpperCase()) : '↗'}</button>
        </div>
      </div>
      ${!isSupabaseConfigured ? '<div class="demo-strip"><span class="status-dot"></span> ДЕМО-КАТАЛОГ · магазины, товары и цены вымышленные · заказы никуда не отправляются</div>' : state.demoMode ? '<div class="demo-strip"><span class="status-dot"></span> Демо-режим · данные сохраняются только на этом устройстве</div>' : ''}
    </header>`;
}

function catalogPage() {
  const products = filteredProducts();
  const featured = state.products.slice(0, 4);
  return `
    <main class="page-shell">
      <section class="hero-section">
        <div class="hero-copy">
          <span class="eyebrow"><i></i> МЕСТНЫЕ МАГАЗИНЫ · ОДНА ВИТРИНА</span>
          <h1>Найди свой стиль.<br><em>Выбирай рядом.</em></h1>
          <p>Смотри коллекции магазинов, сравнивай товары и оформляй заказ в несколько шагов.</p>
          <button class="button button-light" data-action="scroll-catalog">Открыть каталог <span>→</span></button>
          <div class="hero-meta"><span><b>01</b> Выбери товар</span><span><b>02</b> Оформи заказ</span></div>
        </div>
        <div class="hero-visual" aria-hidden="true">
          <div class="hero-image hero-image-main"></div>
          <div class="hero-image hero-image-secondary"></div>
          <div class="hero-sticker"><span>KL</span><small>Мода<br>ближе</small></div>
        </div>
      </section>

      <section class="section category-section">
        <div class="section-heading"><div><span class="eyebrow muted">НАВИГАЦИЯ</span><h2>Что ищешь?</h2></div><span class="heading-note">Выбери категорию</span></div>
        <div class="category-grid">${categories.map((item) => `
          <button class="category-tile" data-action="category" data-id="${item.id}" type="button">
            <span class="category-tile-icon">${item.icon}</span><span>${escapeHtml(item.name)}</span><b>↗</b>
          </button>`).join('')}
        </div>
      </section>

      <section class="section catalog-section" id="catalog-section">
        <div class="section-heading catalog-heading"><div><span class="eyebrow muted">ВИТРИНА</span><h2>Каталог товаров</h2><p>Подборка товаров от магазинов на платформе</p></div><span class="count-label">${products.length} ${pluralize(products.length, ['товар', 'товара', 'товаров'])}</span></div>
        <div class="catalog-toolbar"><div class="category-pills">${categoryPills()}</div><label class="sort-control"><span>Сортировка</span><select id="sort-select"><option value="recommended" ${state.sort === 'recommended' ? 'selected' : ''}>По рекомендации</option><option value="new" ${state.sort === 'new' ? 'selected' : ''}>Сначала новые</option><option value="price-up" ${state.sort === 'price-up' ? 'selected' : ''}>Сначала дешевле</option><option value="price-down" ${state.sort === 'price-down' ? 'selected' : ''}>Сначала дороже</option></select></label></div>
        ${products.length ? `<div class="product-grid">${products.map(productCard).join('')}</div>` : `<div class="empty-state"><div class="empty-icon">⌕</div><h3>Ничего не найдено</h3><p>Попробуй изменить запрос или выбрать другую категорию.</p><button class="button button-outline" data-action="reset-filters">Сбросить фильтры</button></div>`}
      </section>

      <section class="seller-banner"><div><span class="eyebrow muted">ДЛЯ МАГАЗИНОВ</span><h2>У тебя свой магазин?</h2><p>Добавляй товары, принимай заказы и управляй витриной в одном месте.</p></div><button class="button button-dark" data-action="seller-info">Как стать продавцом <span>→</span></button></section>
    </main>`;
}

function pluralize(number, forms) {
  const n = Math.abs(number) % 100;
  const n1 = n % 10;
  if (n > 10 && n < 20) return forms[2];
  if (n1 > 1 && n1 < 5) return forms[1];
  if (n1 === 1) return forms[0];
  return forms[2];
}

function boutiquesPage() {
  return `
    <main class="page-shell inner-page">
      <div class="page-title-row"><div><span class="eyebrow muted">ПАРТНЁРЫ</span><h1>Магазины</h1><p>Открой каталог магазина и посмотри его товары.</p></div><span class="count-label">${state.boutiques.length} магазина</span></div>
      <div class="boutique-grid">${state.boutiques.map((shop) => `
        <article class="boutique-card">
          <div class="boutique-cover" style="background-image:url('${safeImage(shop.cover_url)}')"><span>${shop.verified ? '✓ Проверен' : 'Магазин'}</span></div>
          <div class="boutique-body"><div class="boutique-kicker">${escapeHtml(shop.city || 'Грозный')} · ${escapeHtml(shop.category || 'Одежда')}</div><h3>${escapeHtml(shop.name)}</h3><p>${escapeHtml(shop.description || 'Коллекции и товары магазина.')}</p><button class="text-button" data-action="boutique-products" data-id="${escapeHtml(shop.id)}">Смотреть товары <span>→</span></button></div>
        </article>`).join('')}</div>
      ${!state.boutiques.length ? '<div class="empty-state"><h3>Пока нет магазинов</h3><p>Новые магазины появятся здесь после подключения каталога.</p></div>' : ''}
    </main>`;
}

function favoritesPage() {
  const products = state.favorites.map(getProduct).filter(Boolean);
  return `
    <main class="page-shell inner-page">
      <div class="page-title-row"><div><span class="eyebrow muted">ТВОЯ ПОДБОРКА</span><h1>Избранное</h1><p>Товары, к которым удобно вернуться позже.</p></div><span class="count-label">${products.length} ${pluralize(products.length, ['товар', 'товара', 'товаров'])}</span></div>
      ${products.length ? `<div class="product-grid">${products.map(productCard).join('')}</div>` : `<div class="empty-state"><div class="empty-icon">♡</div><h3>Пока здесь пусто</h3><p>Нажимай на сердечко в карточке товара, чтобы сохранить его.</p><button class="button button-dark" data-action="navigate" data-page="catalog">Перейти в каталог</button></div>`}
    </main>`;
}

function cartPage() {
  if (!state.cart.length) return `
    <main class="page-shell inner-page"><div class="page-title-row"><div><span class="eyebrow muted">ПОКУПКИ</span><h1>Корзина</h1></div></div>
      <div class="empty-state"><div class="empty-icon">▱</div><h3>Корзина пока пустая</h3><p>Добавь понравившийся товар — он появится здесь.</p><button class="button button-dark" data-action="navigate" data-page="catalog">Перейти в каталог</button></div>
    </main>`;
  const lines = state.cart.map((item) => {
    const product = getProduct(item.productId);
    if (!product) return '';
    const key = cartItemKey(product.id, item.size || '');
    const quantity = Math.max(1, Math.min(20, Number(item.quantity) || 1));
    return `<article class="cart-line"><img src="${safeImage(product.image_url || product.image)}" alt="${escapeHtml(product.title)}"><div class="cart-line-info"><span class="product-store">${escapeHtml(product.boutique_name || getBoutique(product.boutique_id)?.name || 'Магазин')}</span><h3>${escapeHtml(product.title)}</h3><small>${item.size ? `Размер: ${escapeHtml(item.size)}` : 'Без размера'}</small><strong>${money(product.price)}</strong></div><div class="quantity-control"><button data-action="quantity" data-key="${key}" data-delta="-1" aria-label="Уменьшить количество">−</button><span>${quantity}</span><button data-action="quantity" data-key="${key}" data-delta="1" aria-label="Увеличить количество">+</button></div><button class="remove-button" data-action="remove-cart" data-key="${key}" aria-label="Удалить">×</button></article>`;
  }).join('');
  return `
    <main class="page-shell inner-page"><div class="page-title-row"><div><span class="eyebrow muted">ПОКУПКИ</span><h1>Корзина</h1><p>Проверь товары перед оформлением заказа.</p></div><span class="count-label">${cartCount()} шт.</span></div>
      <div class="cart-layout"><section class="cart-items">${lines}</section><aside class="checkout-card"><span class="eyebrow muted">ИТОГО</span><div class="checkout-total"><span>Сумма заказа</span><strong>${money(cartTotal())}</strong></div><div class="checkout-note">Доставка и окончательные условия уточняются с магазином после оформления.</div><button class="button button-dark full-width" data-action="checkout">Оформить заказ <span>→</span></button><button class="text-button full-width clear-cart" data-action="clear-cart">Очистить корзину</button></aside></div>
    </main>`;
}

function profilePage() {
  if (!isSignedIn()) return `
    <main class="page-shell inner-page"><div class="page-title-row"><div><span class="eyebrow muted">ЛИЧНЫЙ КАБИНЕТ</span><h1>Профиль</h1><p>Войди по номеру телефона, чтобы управлять заказами.</p></div></div>
      <div class="profile-login-card"><div class="profile-avatar">KL</div><div><h2>Всё в одном месте</h2><p>История заказов, избранное и настройки аккаунта.</p><button class="button button-dark" data-action="open-auth">Войти по номеру телефона</button></div></div>
      <div class="demo-access"><h3>Проверить приложение без SMS</h3><p>Демо-режим нужен только для просмотра. Он не создаёт реальный аккаунт и не отправляет заказы в магазин.</p><div><button class="button button-outline" data-action="demo-login" data-role="customer">Демо покупателя</button><button class="button button-outline" data-action="demo-login" data-role="seller">Демо продавца</button></div></div>
    </main>`;
  const profile = state.profile || {};
  const roleLabel = currentRole() === 'seller' ? 'Продавец' : currentRole() === 'admin' ? 'Администратор' : 'Покупатель';
  return `
    <main class="page-shell inner-page"><div class="page-title-row"><div><span class="eyebrow muted">ЛИЧНЫЙ КАБИНЕТ</span><h1>Профиль</h1><p>Управляй аккаунтом и заказами.</p></div><span class="role-chip">${roleLabel}</span></div>
      <section class="profile-card"><div class="profile-avatar">${escapeHtml((profile.full_name || 'K').slice(0, 1).toUpperCase())}</div><div class="profile-details"><h2>${escapeHtml(profile.full_name || 'Пользователь')}</h2><p>${escapeHtml(profile.phone || state.session?.user?.phone || 'Демо-пользователь')}</p><small>${state.demoMode ? 'Локальный демо-режим' : 'Аккаунт подтверждён по телефону'}</small></div><button class="button button-outline" data-action="logout">Выйти</button></section>
      <div class="profile-actions"><button class="profile-action" data-action="navigate" data-page="orders"><span>▤</span><div><b>Мои заказы</b><small>История и статусы</small></div><i>→</i></button><button class="profile-action" data-action="navigate" data-page="favorites"><span>♡</span><div><b>Избранное</b><small>Сохранённые товары</small></div><i>→</i></button>${currentRole() === 'seller' ? '<button class="profile-action" data-action="navigate" data-page="seller"><span>▣</span><div><b>Кабинет продавца</b><small>Товары и заказы магазина</small></div><i>→</i></button>' : ''}${currentRole() === 'admin' ? '<button class="profile-action" data-action="navigate" data-page="admin"><span>⚙</span><div><b>Администрирование</b><small>Пользователи и магазины</small></div><i>→</i></button>' : ''}</div>
      ${state.demoMode ? '<div class="demo-access compact"><p>Демо-режим. Изменения хранятся только в браузере и будут удалены при очистке данных сайта.</p><button class="text-button" data-action="demo-login" data-role="customer">Сменить на демо покупателя</button><button class="text-button" data-action="demo-login" data-role="seller">Сменить на демо продавца</button></div>' : ''}
    </main>`;
}

function ordersPage() {
  if (!isSignedIn()) return `<main class="page-shell inner-page"><div class="empty-state"><h3>Войдите в аккаунт</h3><p>История заказов доступна после авторизации по телефону.</p><button class="button button-dark" data-action="open-auth">Войти</button></div></main>`;
  let orders = state.orders;
  if (!state.demoMode && supabase) orders = state.orders;
  return `<main class="page-shell inner-page"><div class="page-title-row"><div><span class="eyebrow muted">ЛИЧНЫЙ КАБИНЕТ</span><h1>Мои заказы</h1><p>Статусы и состав оформленных заказов.</p></div></div>
    ${orders.length ? `<div class="orders-list">${orders.map((order) => `<article class="order-card"><div><span class="product-store">${escapeHtml(order.created_at || order.date || 'Только что')}</span><h3>Заказ ${escapeHtml(String(order.id).slice(0, 8))}</h3><small>${escapeHtml(order.status || 'Новый')}</small>${order.order_items?.length ? `<div class="order-items-preview">${order.order_items.map((item) => `${escapeHtml(item.title_snapshot)} × ${Number(item.quantity) || 1}${item.selected_size ? ` · ${escapeHtml(item.selected_size)}` : ''}`).join('<br>')}</div>` : ''}</div><strong>${money(order.total)}</strong></article>`).join('')}</div>` : '<div class="empty-state"><div class="empty-icon">▤</div><h3>Заказов пока нет</h3><p>После оформления заказа его статус появится здесь.</p><button class="button button-dark" data-action="navigate" data-page="catalog">Открыть каталог</button></div>'}</main>`;
}

function sellerPage() {
  if (!isSignedIn() || currentRole() !== 'seller') return `<main class="page-shell inner-page"><div class="empty-state"><h3>Кабинет продавца</h3><p>Доступ выдаётся после проверки магазина администратором.</p><button class="button button-outline" data-action="navigate" data-page="profile">Назад в профиль</button></div></main>`;
  if (!state.demoMode && !state.myBoutique) return `<main class="page-shell inner-page"><div class="page-title-row"><div><span class="eyebrow muted">ПЕРВЫЙ ШАГ</span><h1>Создай магазин</h1><p>Добавь название и основную информацию. После проверки администратором витрина станет доступна покупателям.</p></div></div><div class="profile-login-card"><div class="profile-avatar">+</div><div><h2>У магазина ещё нет витрины</h2><p>Создание займёт пару минут. Публикация товаров станет доступна после сохранения.</p><button class="button button-dark" data-action="create-boutique">Создать магазин</button></div></div></main>`;
  const products = state.demoMode ? state.products.filter((p) => p.boutique_id === 'demo-shop-2') : state.sellerProducts;
  const shopStatus = state.demoMode ? 'Демо' : state.myBoutique?.verified ? 'Проверен' : 'На проверке';
  const orderAction = (order) => {
    if (order.status === 'new') return '<button class="text-button" data-action="set-order-status" data-id="' + escapeHtml(order.id) + '" data-status="confirmed">Подтвердить</button>';
    if (order.status === 'confirmed') return '<button class="text-button" data-action="set-order-status" data-id="' + escapeHtml(order.id) + '" data-status="processing">В работу</button>';
    if (order.status === 'processing') return '<button class="text-button" data-action="set-order-status" data-id="' + escapeHtml(order.id) + '" data-status="completed">Завершить</button>';
    return '';
  };
  return `<main class="page-shell inner-page"><div class="page-title-row"><div><span class="eyebrow muted">УПРАВЛЕНИЕ МАГАЗИНОМ</span><h1>Кабинет продавца</h1><p>${escapeHtml(state.myBoutique?.name || (state.demoMode ? 'Демо-магазин «Форма»' : 'Ваш магазин'))}</p></div><button class="button button-dark" data-action="add-product">+ Добавить товар</button></div>
    ${state.demoMode ? '<div class="demo-note">Демо-режим: добавленные позиции останутся только в этом браузере.</div>' : !state.myBoutique?.verified ? '<div class="security-note"><b>Магазин ожидает проверки</b><p>Ты можешь подготовить карточки товаров. Покупатели увидят их после подтверждения магазина администратором.</p></div>' : ''}
    <div class="seller-stats"><div><span>Товары</span><strong>${products.length}</strong></div><div><span>Заказы</span><strong>${state.sellerOrders.length}</strong></div><div><span>Статус</span><strong>${shopStatus}</strong></div></div>
    <section class="seller-section"><div class="section-heading"><div><h2>Товары магазина</h2><p>Управляй ассортиментом и остатками.</p></div></div>${products.length ? `<div class="seller-product-list">${products.map((p) => `<div class="seller-product-row"><img src="${safeImage(p.image_url || p.image)}" alt="${escapeHtml(p.title)}"><div><b>${escapeHtml(p.title)}</b><small>${money(p.price)} · Остаток: ${Number(p.stock || 0)}</small></div><span class="status-chip">${p.is_active === false ? 'Скрыт' : 'Активен'}</span></div>`).join('')}</div>` : '<div class="empty-inline">Товаров пока нет. Добавь первую позицию.</div>'}</section>
    <section class="seller-section"><div class="section-heading"><div><h2>Последние заказы</h2><p>Контакты и состав заказа доступны только магазину-получателю.</p></div></div>${state.sellerOrders.length ? state.sellerOrders.map((o) => `<article class="seller-order-card"><div class="seller-order-head"><div><b>Заказ ${escapeHtml(String(o.id).slice(0, 8))}</b><small>${escapeHtml(o.status)}</small></div><strong>${money(o.total)}</strong></div><div class="seller-order-details"><b>${escapeHtml(o.buyer_name || 'Покупатель')}</b><span>${escapeHtml(o.buyer_phone || 'Телефон не указан')}</span><span>${escapeHtml(o.delivery_address || 'Адрес не указан')}</span>${o.order_items?.length ? `<div>${o.order_items.map((item) => `${escapeHtml(item.title_snapshot)} × ${Number(item.quantity) || 1}${item.selected_size ? ` · ${escapeHtml(item.selected_size)}` : ''}`).join('<br>')}</div>` : ''}</div><div class="seller-order-actions">${orderAction(o)}${!['completed', 'cancelled'].includes(o.status) ? `<button class="text-button danger-text" data-action="set-order-status" data-id="${escapeHtml(o.id)}" data-status="cancelled">Отменить</button>` : ''}</div></article>`).join('') : '<div class="empty-inline">Заказов пока нет.</div>'}</section>
    </main>`;
}

function adminPage() {
  if (!isSignedIn() || currentRole() !== 'admin') return `<main class="page-shell inner-page"><div class="empty-state"><h3>Нет доступа</h3><p>Этот раздел доступен только администратору.</p></div></main>`;
  const data = state.adminData || { users: [], shops: [], orders: [] };
  return `<main class="page-shell inner-page"><div class="page-title-row"><div><span class="eyebrow muted">УПРАВЛЕНИЕ ПЛАТФОРМОЙ</span><h1>Администрирование</h1><p>Проверка магазинов и управление доступом.</p></div></div>
    <div class="seller-stats"><div><span>Пользователи</span><strong>${data.users.length}</strong></div><div><span>Магазины</span><strong>${data.shops.length}</strong></div><div><span>Заказы</span><strong>${data.orders.length}</strong></div></div>
    <div class="security-note"><b>Административные права</b><p>Действия проверяются на сервере. Роль администратора нельзя назначить из интерфейса.</p></div>
    <section class="seller-section"><h2>Пользователи</h2>${data.users.length ? data.users.map((u) => `<div class="admin-row"><span>${escapeHtml(u.full_name || 'Без имени')}<small>${escapeHtml(u.phone || '')} · ${escapeHtml(u.role || 'customer')} ${u.is_blocked ? '· заблокирован' : ''}</small></span><div class="admin-actions">${u.role !== 'seller' ? `<button class="text-button" data-action="admin-user-role" data-id="${escapeHtml(u.id)}" data-role="seller">Сделать продавцом</button>` : `<button class="text-button" data-action="admin-user-role" data-id="${escapeHtml(u.id)}" data-role="customer">Снять роль продавца</button>`}${u.id !== state.session?.user?.id ? `<button class="text-button ${u.is_blocked ? '' : 'danger-text'}" data-action="admin-user-block" data-id="${escapeHtml(u.id)}" data-blocked="${u.is_blocked ? 'false' : 'true'}">${u.is_blocked ? 'Разблокировать' : 'Заблокировать'}</button>` : ''}</div></div>`).join('') : '<div class="empty-inline">Пользователи появятся после подключения базы.</div>'}</section>
    <section class="seller-section"><h2>Магазины</h2>${data.shops.length ? data.shops.map((shop) => `<div class="admin-row"><span>${escapeHtml(shop.name)}<small>${shop.verified ? 'Проверен' : 'Ожидает проверки'} · ${shop.is_active ? 'Активен' : 'Скрыт'}</small></span><button class="text-button" data-action="admin-shop-verify" data-id="${escapeHtml(shop.id)}" data-verified="${shop.verified ? 'false' : 'true'}">${shop.verified ? 'Снять проверку' : 'Подтвердить магазин'}</button></div>`).join('') : '<div class="empty-inline">Магазины появятся после регистрации продавцов.</div>'}</section>
  </main>`;
}

function footer() {
  return `<footer class="site-footer"><div class="footer-brand"><span class="brand-mark">KL</span><b>Kavkaz Look</b><small>Маркетплейс одежды и магазинов</small></div><div class="footer-links"><button data-action="navigate" data-page="catalog">Каталог</button><button data-action="navigate" data-page="boutiques">Магазины</button><button data-action="navigate" data-page="profile">Профиль</button></div><small>© ${new Date().getFullYear()} Kavkaz Look · MVP</small></footer>`;
}

function mobileNav() {
  const pages = [
    ['catalog', '⌂', 'Главная'], ['boutiques', '▦', 'Магазины'],
    ['favorites', '♡', 'Избранное'], ['cart', '▱', 'Корзина'], ['profile', '○', 'Профиль'],
  ];
  return `<nav class="mobile-nav" aria-label="Мобильная навигация">${pages.map(([page, icon, label]) => `<button class="${state.page === page ? 'active' : ''}" data-action="navigate" data-page="${page}"><span>${icon}</span><small>${label}</small>${page === 'cart' && cartCount() ? `<i>${cartCount()}</i>` : ''}</button>`).join('')}</nav>`;
}

function render() {
  const pages = {
    catalog: catalogPage,
    boutiques: boutiquesPage,
    favorites: favoritesPage,
    cart: cartPage,
    profile: profilePage,
    orders: ordersPage,
    seller: sellerPage,
    admin: adminPage,
  };
  const page = (pages[state.page] || catalogPage)();
  root.innerHTML = `${header()}${page}${footer()}${mobileNav()}`;
  if (state.authOpen) renderAuthModal();
  else if (state.currentProduct) renderProductModal();
  else if (modalRoot) modalRoot.innerHTML = '';
}

function openProduct(productId) {
  const product = getProduct(productId);
  if (!product) return;
  state.currentProduct = product;
  state.selectedSize = product.sizes?.[0] || '';
  render();
}

function renderProductModal() {
  const product = state.currentProduct;
  if (!product) return;
  const image = safeImage(product.image_url || product.image);
  modalRoot.innerHTML = `
    <div class="modal-backdrop" data-action="close-modal">
      <section class="product-modal" role="dialog" aria-modal="true" aria-label="${escapeHtml(product.title)}" data-stop>
        <button class="modal-close" data-action="close-modal" aria-label="Закрыть">×</button>
        <div class="product-modal-image">${image ? `<img src="${image}" alt="${escapeHtml(product.title)}">` : '<div class="product-image-placeholder">K</div>'}</div>
        <div class="product-modal-content"><span class="product-store">${escapeHtml(product.boutique_name || getBoutique(product.boutique_id)?.name || 'Магазин')}</span><h2>${escapeHtml(product.title)}</h2><div class="modal-price">${money(product.price)} ${product.old_price ? `<del>${money(product.old_price)}</del>` : ''}</div><p>${escapeHtml(product.description || 'Описание товара пока не добавлено.')}</p>
          ${product.sizes?.length ? `<div class="variant-block"><b>Размер</b><div class="variant-options">${product.sizes.map((size) => `<button class="variant-option ${state.selectedSize === size ? 'selected' : ''}" data-action="select-size" data-size="${escapeHtml(size)}">${escapeHtml(size)}</button>`).join('')}</div></div>` : ''}
          <div class="modal-actions"><button class="button button-dark" data-action="modal-add" data-id="${escapeHtml(product.id)}">Добавить в корзину</button><button class="button button-outline" data-action="favorite" data-id="${escapeHtml(product.id)}">${isFavorite(product.id) ? '♥ В избранном' : '♡ В избранное'}</button></div>
          <small class="modal-disclaimer">Наличие и условия доставки подтверждает магазин при обработке заказа.</small>
        </div>
      </section>
    </div>`;
}

function renderAuthModal() {
  const otp = state.authStep === 'otp';
  modalRoot.innerHTML = `
    <div class="modal-backdrop" data-action="close-auth">
      <section class="auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-title" data-stop>
        <button class="modal-close" data-action="close-auth" aria-label="Закрыть">×</button>
        <div class="auth-icon">KL</div>
        <span class="eyebrow muted">ЛИЧНЫЙ КАБИНЕТ</span>
        <h2 id="auth-title">${otp ? 'Подтверди номер' : 'Вход или регистрация'}</h2>
        <p>${otp ? `Мы отправили SMS на <b>${escapeHtml(state.authPhone)}</b>. Введи код из сообщения.` : 'Укажи номер телефона. Если аккаунта ещё нет, он будет создан автоматически. Пароль и электронная почта не нужны.'}</p>
        ${otp ? `<form id="otp-form" class="auth-form"><label>Код из SMS<input id="auth-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" placeholder="000000" value="${escapeHtml(state.authCode)}" required></label><button class="button button-dark full-width" type="submit" ${state.authBusy ? 'disabled' : ''}>${state.authBusy ? 'Проверяем…' : 'Подтвердить код'}</button><button class="text-button full-width" type="button" data-action="resend-otp">Отправить код повторно</button><button class="text-button full-width" type="button" data-action="back-auth">Изменить номер</button></form>` : `<form id="phone-form" class="auth-form"><label>Имя <span>необязательно</span><input id="auth-name" type="text" autocomplete="name" maxlength="70" placeholder="Как к вам обращаться?" value="${escapeHtml(state.authName)}"></label><label>Номер телефона<input id="auth-phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+7 (___) ___-__-__" value="${escapeHtml(state.authPhone)}" required></label><button class="button button-dark full-width" type="submit" ${state.authBusy ? 'disabled' : ''}>${state.authBusy ? 'Отправляем…' : 'Получить SMS-код'}</button></form>`}
        ${!isSupabaseConfigured ? `<div class="auth-demo-warning"><b>SMS-авторизация ещё не подключена.</b><span>Для реальных SMS нужны ключи Supabase и настроенный SMS-провайдер. Сейчас можно открыть демонстрационный режим.</span><button class="button button-outline full-width" data-action="demo-login" data-role="customer">Открыть демо покупателя</button></div>` : ''}
        <small class="auth-legal">Номер используется для входа и связи по заказам. Продолжая, ты соглашаешься с обработкой данных согласно политике платформы.</small>
      </section>
    </div>`;
  if (otp) setTimeout(() => document.querySelector('#auth-code')?.focus(), 0);
}

function openAuth(purpose = 'login') {
  state.currentProduct = null;
  state.authOpen = true;
  state.authStep = 'phone';
  state.authPurpose = purpose;
  state.authCode = '';
  state.authBusy = false;
  render();
  setTimeout(() => document.querySelector('#auth-phone')?.focus(), 0);
}

function closeModal() {
  state.currentProduct = null;
  state.authOpen = false;
  modalRoot.innerHTML = '';
}

function setPage(page) {
  state.page = page;
  state.currentProduct = null;
  state.authOpen = false;
  render();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (page === 'seller') loadSellerData();
  if (page === 'admin') loadAdminData();
  if (page === 'orders' && !state.demoMode) loadBuyerOrders();
}

async function sendOtp() {
  const phone = normalizePhone(state.authPhone);
  if (!phone) {
    showToast('Введи корректный номер в формате +7', 'error');
    return;
  }
  if (!isSupabaseConfigured) {
    showToast('SMS пока не подключены. Используй демо-вход.', 'error');
    return;
  }
  try {
    state.authBusy = true;
    renderAuthModal();
    supabase ||= await getSupabase();
    const { error } = await supabase.auth.signInWithOtp({
      phone,
      options: {
        data: state.authName.trim() ? { full_name: state.authName.trim() } : {},
      },
    });
    if (error) throw error;
    state.authPhone = phone;
    state.authStep = 'otp';
    state.authBusy = false;
    state.authCode = '';
    renderAuthModal();
    showToast('SMS-код отправлен');
  } catch (error) {
    state.authBusy = false;
    renderAuthModal();
    showToast(readableError(error), 'error');
  }
}

async function verifyOtp() {
  const phone = normalizePhone(state.authPhone);
  const token = String(state.authCode).replace(/\D/g, '');
  if (!/^\d{6}$/.test(token)) {
    showToast('Введи все 6 цифр из SMS', 'error');
    return;
  }
  try {
    state.authBusy = true;
    renderAuthModal();
    const { data, error } = await supabase.auth.verifyOtp({ phone, token, type: 'sms' });
    if (error) throw error;
    if (!data.session?.user?.id) throw new Error('Сессия не создана. Повтори вход.');
    state.session = data.session;
    state.demoMode = false;
    state.demoRole = null;
    await loadProfile(data.session.user.id);
    if (!state.session) throw new Error('Доступ к аккаунту не подтверждён.');
    state.authOpen = false;
    state.authBusy = false;
    modalRoot.innerHTML = '';
    render();
    if (state.authPurpose === 'checkout') renderCheckoutModal();
    showToast('Вход выполнен');
  } catch (error) {
    state.authBusy = false;
    renderAuthModal();
    showToast(readableError(error), 'error');
  }
}

function readableError(error) {
  const message = String(error?.message || error || 'Неизвестная ошибка');
  if (/rate.?limit|too many|over_sms_send_rate_limit/i.test(message)) return 'Слишком много попыток. Подожди и попробуй позже.';
  if (/invalid.*otp|otp.*invalid|token.*invalid/i.test(message)) return 'Неверный или просроченный код. Запроси новый SMS.';
  if (/network|fetch/i.test(message)) return 'Нет соединения с сервером. Проверь интернет.';
  return message;
}

async function loadProfile(userId) {
  if (!supabase || !userId) return;
  const { data, error } = await supabase.from('profiles')
    .select('id, phone, full_name, role, is_blocked')
    .eq('id', userId)
    .maybeSingle();
  if (error) throw error;
  if (data?.is_blocked) {
    await supabase.auth.signOut();
    state.session = null;
    state.profile = null;
    showToast('Доступ к аккаунту ограничен', 'error');
    return;
  }
  state.profile = data || null;
  if (!data) showToast('Профиль не найден. Проверь SQL-миграцию.', 'error');
}

function startDemo(role = 'customer') {
  state.session = null;
  state.demoMode = true;
  state.demoRole = role === 'seller' ? 'seller' : 'customer';
  state.profile = {
    id: `demo-${state.demoRole}`,
    full_name: state.demoRole === 'seller' ? 'Демо-продавец' : 'Демо-покупатель',
    phone: '+7 999 000-00-00', role: state.demoRole,
  };
  state.authOpen = false;
  state.currentProduct = null;
  modalRoot.innerHTML = '';
  setPage(state.demoRole === 'seller' ? 'seller' : 'catalog');
  showToast('Открыт демонстрационный режим');
}

async function logout() {
  try {
    if (state.session && supabase) await supabase.auth.signOut();
  } catch (error) {
    console.error('Sign out failed:', error);
  }
  state.session = null;
  state.profile = null;
  state.demoMode = false;
  state.demoRole = null;
  state.myBoutique = null;
  state.page = 'catalog';
  render();
  showToast('Вы вышли из аккаунта');
}

function addModalProduct(productId) {
  const product = getProduct(productId);
  if (!product) return;
  const size = state.selectedSize;
  const exists = state.cart.find((item) => String(item.productId) === String(productId) && String(item.size || '') === String(size || ''));
  if (exists) exists.quantity = Math.min(20, Number(exists.quantity || 1) + 1);
  else state.cart.push({ productId, quantity: 1, size });
  persist();
  state.currentProduct = null;
  modalRoot.innerHTML = '';
  render();
  showToast('Добавлено в корзину');
}

function changeQuantity(key, delta) {
  const decoded = decodeCartItemKey(key);
  if (!decoded) return;
  const item = state.cart.find((entry) => String(entry.productId) === decoded.productId && String(entry.size || '') === decoded.size);
  if (!item) return;
  item.quantity = Math.max(1, Math.min(20, Number(item.quantity || 1) + delta));
  persist();
  render();
}

function removeFromCart(key) {
  const decoded = decodeCartItemKey(key);
  if (!decoded) return;
  state.cart = state.cart.filter((entry) => !(String(entry.productId) === decoded.productId && String(entry.size || '') === decoded.size));
  persist();
  render();
}

function checkout() {
  if (!isSignedIn()) {
    openAuth('checkout');
    showToast('Войди по номеру телефона, чтобы оформить заказ');
    return;
  }
  if (state.demoMode) {
    const order = {
      id: `DEMO-${Date.now()}`,
      date: new Date().toLocaleString('ru-RU'),
      created_at: new Date().toLocaleString('ru-RU'),
      status: 'Новый · демо', total: cartTotal(),
    };
    state.orders.unshift(order);
    state.cart = [];
    persist();
    setPage('orders');
    showToast('Демо-заказ создан на этом устройстве');
    return;
  }
  renderCheckoutModal();
}

function renderCheckoutModal() {
  modalRoot.innerHTML = `<div class="modal-backdrop" data-action="close-modal"><section class="checkout-modal" role="dialog" aria-modal="true" data-stop><button class="modal-close" data-action="close-modal">×</button><span class="eyebrow muted">ПОСЛЕДНИЙ ШАГ</span><h2>Оформление заказа</h2><p>Укажи адрес или способ связи. Магазин подтвердит наличие и доставку.</p><form id="checkout-form" class="auth-form"><label>Имя получателя<input id="checkout-name" maxlength="70" value="${escapeHtml(state.profile?.full_name || '')}" required></label><label>Подтверждённый телефон<input id="checkout-phone" type="tel" value="${escapeHtml(state.profile?.phone || state.session?.user?.phone || '')}" readonly></label><label>Адрес / комментарий<input id="checkout-address" maxlength="250" placeholder="Район, улица или самовывоз" required></label><div class="checkout-total"><span>К оплате</span><strong>${money(cartTotal())}</strong></div><button class="button button-dark full-width" type="submit">Подтвердить заказ</button></form><small class="auth-legal">В MVP онлайн-оплата не подключена. Заказ отправляется магазину на подтверждение.</small></section></div>`;
}

async function placeOrder(form) {
  const address = form.querySelector('#checkout-address').value.trim();
  if (!address) return showToast('Укажи адрес или самовывоз', 'error');
  if (!state.cart.length) return;
  const recipientName = form.querySelector('#checkout-name').value.trim();
  if (recipientName.length < 2) return showToast('Укажи имя получателя', 'error');
  try {
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    button.textContent = 'Оформляем…';
    supabase ||= await getSupabase();
    const { error: profileError } = await supabase.from('profiles').update({ full_name: recipientName }).eq('id', state.session.user.id);
    if (profileError) throw profileError;
    const items = state.cart.map((item) => ({ product_id: item.productId, quantity: item.quantity, selected_size: item.size || null }));
    const { data, error } = await supabase.rpc('place_cart_orders', {
      p_items: items,
      p_delivery_address: address,
    });
    if (error) throw error;
    if (data && !Array.isArray(data) && data.error) {
      const messages = {
        rate_limited: 'Слишком много попыток оформления. Повтори позже.',
        invalid_delivery_address: 'Проверь адрес или комментарий.',
        invalid_cart: 'Корзина пустая или содержит слишком много позиций.',
        invalid_cart_item: 'В корзине обнаружены некорректные позиции.',
        product_unavailable: 'Один из товаров больше недоступен.',
        not_enough_stock: 'Не хватает товара в наличии. Обнови корзину.',
        store_unavailable: 'Один из магазинов временно недоступен.',
        invalid_size: 'Выбранный размер больше недоступен.',
      };
      throw new Error(messages[data.error] || 'Не удалось оформить заказ.');
    }
    state.cart = [];
    persist();
    state.orders = [];
    state.currentProduct = null;
    modalRoot.innerHTML = '';
    await loadBuyerOrders();
    setPage('orders');
    showToast(`Заказ оформлен. Создано: ${Array.isArray(data) ? data.length : 1}`);
  } catch (error) {
    showToast(readableError(error), 'error');
    const button = form.querySelector('button[type="submit"]');
    if (button) { button.disabled = false; button.textContent = 'Подтвердить заказ'; }
  }
}

async function loadProducts() {
  if (!isSupabaseConfigured) return;
  try {
    supabase ||= await getSupabase();
    const { data, error } = await supabase.functions.invoke('public-catalog', { body: { limit: 48 } });
    if (error) throw error;
    state.products = (data?.products || []).map((item) => ({
      ...item,
      boutique_name: item.boutiques?.name || 'Магазин',
      badge: '',
    }));
    state.boutiques = data?.boutiques || [];
    const validIds = new Set(state.products.map((item) => String(item.id)));
    const previousCartCount = state.cart.length;
    state.cart = state.cart.filter((item) => validIds.has(String(item.productId)));
    if (state.cart.length !== previousCartCount) {
      persist();
      showToast('Старые демо-позиции удалены из корзины после подключения каталога');
    }
    render();
  } catch (error) {
    console.error('Catalog load failed:', error);
    showToast('Не удалось загрузить каталог из базы. Проверь миграцию и RLS.', 'error');
  }
}

async function loadFavorites() {
  if (!supabase || !state.session) return;
  try {
    const { data, error } = await supabase.from('favorites').select('product_id').eq('user_id', state.session.user.id).limit(200);
    if (error) throw error;
    state.favorites = (data || []).map((item) => item.product_id);
    persist();
  } catch (error) { console.error('Favorites load failed:', error); }
}

async function changeSellerOrderStatus(orderId, status) {
  if (state.demoMode) {
    const order = state.sellerOrders.find((item) => item.id === orderId);
    if (order) order.status = status;
    render();
    showToast('Статус демо-заказа обновлён');
    return;
  }
  try {
    const { error } = await supabase.rpc('set_order_status', { p_order_id: orderId, p_status: status });
    if (error) throw error;
    await loadSellerData();
    showToast('Статус заказа обновлён');
  } catch (error) { showToast(readableError(error), 'error'); }
}

async function loadBuyerOrders() {
  if (!supabase || !state.session) return;
  try {
    const { data, error } = await supabase.from('orders')
      .select('id, status, total, created_at, order_items(title_snapshot, quantity, selected_size)')
      .order('created_at', { ascending: false })
      .limit(30);
    if (error) throw error;
    state.orders = data || [];
    render();
  } catch (error) {
    showToast('Не удалось загрузить заказы', 'error');
  }
}

async function loadSellerData() {
  if (state.demoMode) return;
  if (!supabase || !state.session || currentRole() !== 'seller') return;
  try {
    const { data: shop, error: shopError } = await supabase.from('boutiques')
      .select('id, name, description, city, verified, is_active')
      .eq('owner_id', state.session.user.id)
      .maybeSingle();
    if (shopError) throw shopError;
    state.myBoutique = shop;
    if (!shop) {
      showToast('К аккаунту ещё не привязан магазин', 'error');
      render();
      return;
    }
    const [productsResult, ordersResult] = await Promise.all([
      supabase.from('products').select('id, title, price, image_url, stock, is_active').eq('boutique_id', shop.id).order('created_at', { ascending: false }).limit(50),
      supabase.from('orders').select('id, status, total, created_at, buyer_name, buyer_phone, delivery_address, order_items(title_snapshot, quantity, selected_size)').eq('boutique_id', shop.id).order('created_at', { ascending: false }).limit(30),
    ]);
    if (productsResult.error) throw productsResult.error;
    if (ordersResult.error) throw ordersResult.error;
    state.sellerProducts = productsResult.data || [];
    state.sellerOrders = ordersResult.data || [];
    render();
  } catch (error) {
    showToast('Не удалось загрузить кабинет продавца', 'error');
    console.error(error);
  }
}

async function performAdminRpc(functionName, args, successMessage) {
  if (!supabase || !state.session || currentRole() !== 'admin') return;
  try {
    const { error } = await supabase.rpc(functionName, args);
    if (error) throw error;
    await loadAdminData();
    showToast(successMessage);
  } catch (error) {
    showToast(readableError(error), 'error');
  }
}

async function loadAdminData() {
  if (state.demoMode || !supabase || !state.session || currentRole() !== 'admin') return;
  try {
    const [users, shops, orders] = await Promise.all([
      supabase.from('profiles').select('id, full_name, phone, role, is_blocked').order('created_at', { ascending: false }).limit(100),
      supabase.from('boutiques').select('id, name, verified, is_active').limit(100),
      supabase.from('orders').select('id, status, total').limit(100),
    ]);
    if (users.error) throw users.error;
    if (shops.error) throw shops.error;
    if (orders.error) throw orders.error;
    state.adminData = { users: users.data || [], shops: shops.data || [], orders: orders.data || [] };
    render();
  } catch (error) {
    showToast('Нет доступа к административным данным или не настроены политики RLS', 'error');
  }
}

function renderCreateBoutiqueModal() {
  modalRoot.innerHTML = `<div class="modal-backdrop" data-action="close-modal"><section class="checkout-modal" role="dialog" aria-modal="true" data-stop><button class="modal-close" data-action="close-modal">×</button><span class="eyebrow muted">КАБИНЕТ ПРОДАВЦА</span><h2>Новый магазин</h2><p>Укажи достоверные данные. Витрина появится в каталоге после проверки.</p><form id="create-boutique-form" class="auth-form"><label>Название магазина<input id="shop-name" maxlength="100" required placeholder="Название витрины"></label><label>Категория<select id="shop-category"><option>Женская одежда</option><option>Мужская одежда</option><option>Обувь</option><option>Сумки и аксессуары</option><option>Другое</option></select></label><label>Город<input id="shop-city" maxlength="80" value="Грозный" required></label><label>Описание<textarea id="shop-description" maxlength="500" rows="3" placeholder="Что продаёт магазин?"></textarea></label><label>Телефон магазина<input id="shop-phone" type="tel" maxlength="30" placeholder="+7..."></label><button class="button button-dark full-width" type="submit">Создать витрину</button></form></section></div>`;
}

async function createBoutique(form) {
  if (!state.session || currentRole() !== 'seller' || state.demoMode) return showToast('Нужен подтверждённый аккаунт продавца', 'error');
  const payload = {
    owner_id: state.session.user.id,
    name: form.querySelector('#shop-name').value.trim(),
    category: form.querySelector('#shop-category').value,
    city: form.querySelector('#shop-city').value.trim(),
    description: form.querySelector('#shop-description').value.trim(),
    phone: form.querySelector('#shop-phone').value.trim() || state.profile?.phone || null,
  };
  if (payload.name.length < 2 || payload.city.length < 2) return showToast('Проверь название и город', 'error');
  try {
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    button.textContent = 'Сохраняем…';
    const { data, error } = await supabase.from('boutiques').insert(payload).select('id, name, description, city, verified, is_active').single();
    if (error) throw error;
    state.myBoutique = data;
    modalRoot.innerHTML = '';
    await loadSellerData();
    showToast('Магазин создан. Осталось пройти проверку.');
  } catch (error) {
    showToast(readableError(error), 'error');
    const button = form.querySelector('button[type="submit"]');
    if (button) { button.disabled = false; button.textContent = 'Создать витрину'; }
  }
}

function renderAddProductModal() {
  modalRoot.innerHTML = `<div class="modal-backdrop" data-action="close-modal"><section class="checkout-modal" role="dialog" aria-modal="true" data-stop><button class="modal-close" data-action="close-modal">×</button><span class="eyebrow muted">КАБИНЕТ ПРОДАВЦА</span><h2>Новый товар</h2><form id="add-product-form" class="auth-form"><label>Название<input id="new-title" maxlength="100" required placeholder="Например, платье прямого кроя"></label><label>Категория<select id="new-category">${categories.map((c) => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('')}</select></label><label>Цена, ₽<input id="new-price" type="number" min="1" max="10000000" step="1" required></label><label>Ссылка на фото<input id="new-image" type="url" maxlength="500" placeholder="https://..."></label><label>Описание<textarea id="new-description" maxlength="1000" rows="3"></textarea></label><label>Размеры <span>через запятую, если нужны</span><input id="new-sizes" maxlength="120" placeholder="S, M, L"></label><label>Остаток<input id="new-stock" type="number" min="0" max="100000" value="1"></label><button class="button button-dark full-width" type="submit">Сохранить товар</button></form></section></div>`;
}

async function addProduct(form) {
  const item = {
    title: form.querySelector('#new-title').value.trim(),
    category: form.querySelector('#new-category').value,
    price: Number(form.querySelector('#new-price').value),
    image_url: form.querySelector('#new-image').value.trim(),
    description: form.querySelector('#new-description').value.trim(),
    stock: Number(form.querySelector('#new-stock').value),
    sizes: (form.querySelector('#new-sizes')?.value || '').split(',').map((size) => size.trim()).filter(Boolean).slice(0, 20),
  };
  if (!item.title || !Number.isFinite(item.price) || item.price <= 0) return showToast('Проверь название и цену', 'error');
  if (item.image_url && !item.image_url.startsWith('https://')) return showToast('Фото должно иметь HTTPS-ссылку', 'error');
  try {
    if (state.demoMode) {
      const newItem = {
        ...item, id: `demo-new-${Date.now()}`, boutique_id: 'demo-shop-2', boutique_name: 'Магазин «Форма»',
        is_active: true, sizes: item.sizes, colors: [],
      };
      state.products.unshift(newItem);
      state.demoAddedProducts.unshift(newItem);
      persist();
      state.currentProduct = null;
      modalRoot.innerHTML = '';
      render();
      showToast('Демо-товар добавлен');
      return;
    }
    if (!state.myBoutique?.id) throw new Error('К аккаунту не привязан магазин');
    const { error } = await supabase.from('products').insert({ ...item, boutique_id: state.myBoutique.id, is_active: true });
    if (error) throw error;
    modalRoot.innerHTML = '';
    await loadSellerData();
    showToast('Товар сохранён');
  } catch (error) {
    showToast(readableError(error), 'error');
  }
}

function sellerInfo() {
  modalRoot.innerHTML = `<div class="modal-backdrop" data-action="close-modal"><section class="checkout-modal" role="dialog" aria-modal="true" data-stop><button class="modal-close" data-action="close-modal">×</button><span class="eyebrow muted">ДЛЯ МАГАЗИНОВ</span><h2>Подключение магазина</h2><p>В MVP продавец получает доступ после проверки администратором. Это защищает покупателей от поддельных витрин и случайных аккаунтов.</p><div class="security-note"><b>Что понадобится</b><p>Название и контакты магазина, подтверждение права управлять им и актуальный ассортимент. Самостоятельно назначить себе роль продавца нельзя.</p></div><button class="button button-dark full-width" data-action="close-modal">Понятно</button></section></div>`;
}

// Single delegated handler keeps interactions predictable and avoids rebinding on each render.
document.addEventListener('click', async (event) => {
  const target = event.target.closest('[data-action]');
  const insideModal = event.target.closest('[data-stop]');
  if (insideModal && (!target || target.classList.contains('modal-backdrop'))) return;
  if (!target) return;
  const action = target.dataset.action;
  const id = target.dataset.id;
  if (action === 'stop') return;

  switch (action) {
    case 'navigate': setPage(target.dataset.page); break;
    case 'category': state.category = target.dataset.id; state.page = 'catalog'; render(); document.querySelector('#catalog-section')?.scrollIntoView({ behavior: 'smooth' }); break;
    case 'add': {
      event.stopPropagation();
      const product = getProduct(id);
      if (product?.sizes?.length) openProduct(id);
      else saveCartItem(id);
      break;
    }
    case 'open-product': openProduct(id); break;
    case 'favorite': event.stopPropagation(); toggleFavorite(id); if (state.currentProduct) renderProductModal(); break;
    case 'modal-add': addModalProduct(id); break;
    case 'select-size': state.selectedSize = target.dataset.size; renderProductModal(); break;
    case 'close-modal': closeModal(); render(); break;
    case 'close-auth': if (event.target === target || target.classList.contains('modal-close')) { state.authOpen = false; modalRoot.innerHTML = ''; } break;
    case 'open-auth': openAuth(); break;
    case 'demo-login': startDemo(target.dataset.role); break;
    case 'back-auth': state.authStep = 'phone'; state.authCode = ''; renderAuthModal(); break;
    case 'resend-otp': state.authStep = 'phone'; state.authCode = ''; await sendOtp(); break;
    case 'logout': await logout(); break;
    case 'quantity': changeQuantity(target.dataset.key, Number(target.dataset.delta)); break;
    case 'remove-cart': removeFromCart(target.dataset.key); break;
    case 'clear-cart': state.cart = []; persist(); render(); break;
    case 'checkout': checkout(); break;
    case 'boutique-products': {
      const shop = getBoutique(id);
      state.query = shop?.name || '';
      state.category = 'all';
      setPage('catalog');
      const input = document.querySelector('#header-search-input');
      if (input) input.value = state.query;
      break;
    }
    case 'seller-info': sellerInfo(); break;
    case 'create-boutique': renderCreateBoutiqueModal(); break;
    case 'add-product': renderAddProductModal(); break;
    case 'admin-user-role': await performAdminRpc('set_user_role', { p_user_id: id, p_role: target.dataset.role }, 'Роль пользователя обновлена'); break;
    case 'admin-user-block': await performAdminRpc('set_user_blocked', { p_user_id: id, p_blocked: target.dataset.blocked === 'true' }, target.dataset.blocked === 'true' ? 'Пользователь заблокирован' : 'Доступ восстановлен'); break;
    case 'admin-shop-verify': await performAdminRpc('set_boutique_verified', { p_boutique_id: id, p_verified: target.dataset.verified === 'true' }, 'Статус магазина обновлён'); break;
    case 'set-order-status': await changeSellerOrderStatus(target.dataset.id, target.dataset.status); break;
    case 'scroll-catalog': document.querySelector('#catalog-section')?.scrollIntoView({ behavior: 'smooth' }); break;
    case 'reset-filters': state.query = ''; state.category = 'all'; state.sort = 'recommended'; render(); break;
  }
});

document.addEventListener('submit', async (event) => {
  if (event.target.id === 'phone-form') {
    event.preventDefault();
    state.authName = document.querySelector('#auth-name')?.value || '';
    state.authPhone = document.querySelector('#auth-phone')?.value || '';
    await sendOtp();
  }
  if (event.target.id === 'otp-form') {
    event.preventDefault();
    state.authCode = document.querySelector('#auth-code')?.value || '';
    await verifyOtp();
  }
  if (event.target.id === 'checkout-form') {
    event.preventDefault();
    await placeOrder(event.target);
  }
  if (event.target.id === 'add-product-form') {
    event.preventDefault();
    await addProduct(event.target);
  }
  if (event.target.id === 'create-boutique-form') {
    event.preventDefault();
    await createBoutique(event.target);
  }
});

document.addEventListener('input', (event) => {
  if (event.target.id === 'header-search-input') {
    const cursor = event.target.selectionStart;
    state.query = event.target.value;
    const page = state.page;
    if (page !== 'catalog') state.page = 'catalog';
    render();
    const input = document.querySelector('#header-search-input');
    input?.focus();
    input?.setSelectionRange(cursor, cursor);
  }
  if (event.target.id === 'auth-phone') {
    const start = event.target.selectionStart;
    event.target.value = formatPhone(event.target.value);
    try { event.target.setSelectionRange(start, start); } catch { /* mobile selection can be unavailable */ }
  }
});

document.addEventListener('change', (event) => {
  if (event.target.id === 'sort-select') {
    state.sort = event.target.value;
    render();
  }
});

document.addEventListener('keydown', (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    document.querySelector('#header-search-input')?.focus();
  }
  if (event.key === 'Escape') {
    if (state.authOpen || state.currentProduct || modalRoot.innerHTML) {
      state.authOpen = false;
      state.currentProduct = null;
      modalRoot.innerHTML = '';
    }
  }
});

async function initialize() {
  render();
  if (!isSupabaseConfigured) return;
  try {
    supabase = await getSupabase();
    const { data: { session } } = await supabase.auth.getSession();
    state.session = session;
    if (session?.user) { await loadProfile(session.user.id); await loadFavorites(); }
    const { data } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      state.session = nextSession;
      if (!nextSession) state.profile = null;
      else setTimeout(() => loadProfile(nextSession.user.id).then(loadFavorites).then(render).catch((error) => console.error(error)), 0);
      render();
    });
    authSubscription = data.subscription;
    await loadProducts();
    render();
  } catch (error) {
    console.error('Initialization failed:', error);
    showToast('Не удалось связаться с Supabase. Работаем с демо-каталогом.', 'error');
  }
}

window.addEventListener('beforeunload', () => authSubscription?.unsubscribe());
initialize();
