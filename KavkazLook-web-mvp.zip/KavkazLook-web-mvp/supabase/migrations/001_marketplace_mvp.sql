-- Kavkaz Look: secure marketplace MVP schema.
-- Run in Supabase SQL Editor or through Supabase CLI migrations.
-- Never expose a Supabase service_role/secret key in the browser.

create extension if not exists pgcrypto;

-- -----------------------------------------------------------------------------
-- Roles and helper functions
-- -----------------------------------------------------------------------------

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique,
  full_name text not null default '' check (char_length(full_name) <= 70),
  role text not null default 'customer' check (role in ('customer', 'seller', 'admin')),
  is_blocked boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin' and p.is_blocked = false
  );
$$;

create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.profiles (id, phone, full_name)
  values (
    new.id,
    new.phone,
    left(coalesce(new.raw_user_meta_data ->> 'full_name', ''), 70)
  )
  on conflict (id) do update
    set phone = excluded.phone,
        updated_at = now();
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_kavkazlook on auth.users;
create trigger on_auth_user_created_kavkazlook
after insert on auth.users
for each row execute procedure public.handle_new_auth_user();

-- -----------------------------------------------------------------------------
-- Marketplace tables
-- -----------------------------------------------------------------------------

create table if not exists public.boutiques (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete restrict,
  name text not null check (char_length(name) between 2 and 100),
  description text not null default '',
  category text not null default 'Одежда',
  city text not null default 'Грозный',
  phone text,
  cover_url text,
  verified boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_seller_owner(p_boutique_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1
    from public.boutiques b
    join public.profiles p on p.id = b.owner_id
    where b.id = p_boutique_id
      and b.owner_id = auth.uid()
      and p.role = 'seller'
      and p.is_blocked = false
  );
$$;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  boutique_id uuid not null references public.boutiques(id) on delete restrict,
  title text not null check (char_length(title) between 2 and 120),
  description text not null default '',
  category text not null check (category in ('women', 'men', 'shoes', 'bags', 'accessories')),
  price numeric(12,2) not null check (price > 0 and price <= 10000000),
  old_price numeric(12,2) check (old_price is null or (old_price > 0 and old_price <= 10000000)),
  image_url text,
  sizes text[] not null default '{}',
  colors text[] not null default '{}',
  stock integer not null default 0 check (stock between 0 and 100000),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles(id) on delete restrict,
  boutique_id uuid not null references public.boutiques(id) on delete restrict,
  buyer_name text not null,
  buyer_phone text not null,
  delivery_address text not null,
  status text not null default 'new' check (status in ('new', 'confirmed', 'processing', 'completed', 'cancelled')),
  total numeric(12,2) not null check (total > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  title_snapshot text not null,
  price_at_purchase numeric(12,2) not null check (price_at_purchase > 0),
  quantity integer not null check (quantity between 1 and 20),
  selected_size text,
  created_at timestamptz not null default now()
);

create table if not exists public.favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, product_id)
);

-- A tiny per-account write limiter for the checkout RPC.
create table if not exists public.order_rate_limits (
  user_id uuid primary key references auth.users(id) on delete cascade,
  window_started_at timestamptz not null default now(),
  request_count integer not null default 0
);

create unique index if not exists idx_boutiques_owner_unique on public.boutiques(owner_id);
create index if not exists idx_boutiques_active on public.boutiques(is_active, name);
create index if not exists idx_products_boutique_active on public.products(boutique_id, is_active, created_at desc);
create index if not exists idx_products_category on public.products(category, is_active);
create index if not exists idx_orders_buyer_created on public.orders(buyer_id, created_at desc);
create index if not exists idx_orders_boutique_created on public.orders(boutique_id, created_at desc);
create index if not exists idx_order_items_order on public.order_items(order_id);
create index if not exists idx_favorites_user on public.favorites(user_id);

-- -----------------------------------------------------------------------------
-- Updated-at triggers
-- -----------------------------------------------------------------------------

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute procedure public.set_updated_at();
drop trigger if exists boutiques_set_updated_at on public.boutiques;
create trigger boutiques_set_updated_at before update on public.boutiques
for each row execute procedure public.set_updated_at();
drop trigger if exists products_set_updated_at on public.products;
create trigger products_set_updated_at before update on public.products
for each row execute procedure public.set_updated_at();
drop trigger if exists orders_set_updated_at on public.orders;
create trigger orders_set_updated_at before update on public.orders
for each row execute procedure public.set_updated_at();

-- -----------------------------------------------------------------------------
-- Role-management RPC: only an existing admin can promote a customer to seller.
-- The first admin must be assigned manually in the trusted SQL editor.
-- -----------------------------------------------------------------------------

create or replace function public.set_user_role(p_user_id uuid, p_role text)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  if p_role is null or p_role not in ('customer', 'seller') then
    raise exception 'invalid role';
  end if;
  update public.profiles set role = p_role where id = p_user_id;
  if not found then raise exception 'profile not found'; end if;
end;
$$;

create or replace function public.set_user_blocked(p_user_id uuid, p_blocked boolean)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if not public.is_admin() then raise exception 'forbidden' using errcode = '42501'; end if;
  if p_user_id is null or p_blocked is null then raise exception 'invalid arguments'; end if;
  if p_user_id = auth.uid() then raise exception 'cannot change your own access'; end if;
  update public.profiles set is_blocked = p_blocked where id = p_user_id;
  if not found then raise exception 'profile not found'; end if;
end;
$$;

create or replace function public.set_boutique_verified(p_boutique_id uuid, p_verified boolean)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if not public.is_admin() then raise exception 'forbidden' using errcode = '42501'; end if;
  if p_boutique_id is null or p_verified is null then raise exception 'invalid arguments'; end if;
  update public.boutiques set verified = p_verified where id = p_boutique_id;
  if not found then raise exception 'boutique not found'; end if;
end;
$$;

-- -----------------------------------------------------------------------------
-- Atomic checkout. Server reads current prices and stock; client prices are
-- never trusted. One RPC can create one sub-order per boutique in one transaction.
-- At most 5 checkout RPC calls per account every 10 minutes.
-- -----------------------------------------------------------------------------

create or replace function public.place_cart_orders(
  p_items jsonb,
  p_delivery_address text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_profile public.profiles%rowtype;
  v_entry record;
  v_product public.products%rowtype;
  v_shop_id uuid;
  v_order_id uuid;
  v_total numeric(12,2);
  v_order_ids jsonb := '[]'::jsonb;
  v_valid_count integer;
  v_request_count integer;
begin
  if v_user_id is null then
    raise exception 'authentication required' using errcode = '42501';
  end if;
  select * into v_profile from public.profiles where id = v_user_id;
  if not found or v_profile.is_blocked then
    raise exception 'account unavailable' using errcode = '42501';
  end if;

  -- The counter must commit even when a checkout is rejected. Return structured
  -- errors below instead of raising exceptions after this point, because an
  -- exception would roll back the counter update with the transaction.
  insert into public.order_rate_limits(user_id, window_started_at, request_count)
  values (v_user_id, now(), 0)
  on conflict (user_id) do nothing;
  select request_count into v_request_count
  from public.order_rate_limits where user_id = v_user_id for update;
  update public.order_rate_limits
  set window_started_at = case when window_started_at < now() - interval '10 minutes' then now() else window_started_at end,
      request_count = case when window_started_at < now() - interval '10 minutes' then 1 else request_count + 1 end
  where user_id = v_user_id
  returning request_count into v_request_count;
  if v_request_count > 5 then
    return jsonb_build_object('error', 'rate_limited', 'retry_after_seconds', 600);
  end if;

  if coalesce(char_length(trim(p_delivery_address)), 0) < 3 or char_length(p_delivery_address) > 250 then
    return jsonb_build_object('error', 'invalid_delivery_address');
  end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    return jsonb_build_object('error', 'invalid_cart');
  end if;
  if jsonb_array_length(p_items) < 1 or jsonb_array_length(p_items) > 40 then
    return jsonb_build_object('error', 'invalid_cart');
  end if;

  -- Validate raw JSON before casting to UUID/integer. This prevents malformed
  -- client input from raising and rolling back the committed rate-limit count.
  if exists (
    select 1
    from jsonb_array_elements(p_items) as e(value)
    where jsonb_typeof(e.value) <> 'object'
       or coalesce(e.value ->> 'product_id', '') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
       or coalesce(e.value ->> 'quantity', '') !~ '^([1-9]|1[0-9]|20)$'
       or (e.value ? 'selected_size' and e.value -> 'selected_size' <> 'null'::jsonb
           and (jsonb_typeof(e.value -> 'selected_size') <> 'string' or char_length(e.value ->> 'selected_size') > 40))
  ) then
    return jsonb_build_object('error', 'invalid_cart_item');
  end if;

  select count(*) into v_valid_count
  from jsonb_to_recordset(p_items) as item(product_id uuid, quantity integer, selected_size text)
  join public.products p on p.id = item.product_id
  where item.quantity between 1 and 20;
  if v_valid_count <> jsonb_array_length(p_items) then
    return jsonb_build_object('error', 'product_unavailable');
  end if;

  -- Lock every product once in a stable order; aggregate quantity by product so
  -- duplicate cart lines cannot bypass the stock check.
  for v_entry in
    select p.id as product_id, sum(item.quantity)::integer as total_quantity
    from jsonb_to_recordset(p_items) as item(product_id uuid, quantity integer, selected_size text)
    join public.products p on p.id = item.product_id
    group by p.id
    order by p.id
  loop
    select * into v_product from public.products where id = v_entry.product_id for update;
    if not found or not v_product.is_active then
      return jsonb_build_object('error', 'product_unavailable');
    end if;
    if v_product.stock < v_entry.total_quantity then
      return jsonb_build_object('error', 'not_enough_stock', 'product_id', v_product.id);
    end if;
    if not exists (
      select 1 from public.boutiques b
      where b.id = v_product.boutique_id and b.is_active = true
    ) then
      return jsonb_build_object('error', 'store_unavailable');
    end if;
  end loop;

  -- Every selected size must belong to its product. Products without a size
  -- list accept a null size.
  if exists (
    select 1
    from jsonb_to_recordset(p_items) as item(product_id uuid, quantity integer, selected_size text)
    join public.products p on p.id = item.product_id
    where coalesce(array_length(p.sizes, 1), 0) > 0
      and (item.selected_size is null or not (item.selected_size = any(p.sizes)))
  ) then
    return jsonb_build_object('error', 'invalid_size');
  end if;

  -- All checks have completed before the first write. Multiple shops create
  -- separate orders but the whole function remains one atomic transaction.
  for v_shop_id in
    select distinct p.boutique_id
    from jsonb_to_recordset(p_items) as item(product_id uuid, quantity integer, selected_size text)
    join public.products p on p.id = item.product_id
    order by p.boutique_id
  loop
    select sum(p.price * item.quantity)::numeric(12,2) into v_total
    from jsonb_to_recordset(p_items) as item(product_id uuid, quantity integer, selected_size text)
    join public.products p on p.id = item.product_id
    where p.boutique_id = v_shop_id;

    insert into public.orders (buyer_id, boutique_id, buyer_name, buyer_phone, delivery_address, status, total)
    values (
      v_user_id, v_shop_id,
      coalesce(nullif(trim(v_profile.full_name), ''), 'Покупатель'),
      coalesce(v_profile.phone, ''),
      trim(p_delivery_address), 'new', v_total
    ) returning id into v_order_id;

    insert into public.order_items (order_id, product_id, title_snapshot, price_at_purchase, quantity, selected_size)
    select v_order_id, p.id, p.title, p.price, item.quantity, item.selected_size
    from jsonb_to_recordset(p_items) as item(product_id uuid, quantity integer, selected_size text)
    join public.products p on p.id = item.product_id
    where p.boutique_id = v_shop_id;

    v_order_ids := v_order_ids || jsonb_build_array(v_order_id);
  end loop;

  update public.products p
  set stock = p.stock - grouped.total_quantity
  from (
    select item.product_id, sum(item.quantity)::integer as total_quantity
    from jsonb_to_recordset(p_items) as item(product_id uuid, quantity integer, selected_size text)
    group by item.product_id
  ) grouped
  where p.id = grouped.product_id;

  return v_order_ids;
end;
$$;

create or replace function public.set_order_status(p_order_id uuid, p_status text)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_order public.orders%rowtype;
begin
  if auth.uid() is null then raise exception 'authentication required' using errcode = '42501'; end if;
  if p_status is null or p_status not in ('confirmed', 'processing', 'completed', 'cancelled') then raise exception 'invalid status'; end if;
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;
  if not public.is_admin() and not public.is_seller_owner(v_order.boutique_id) then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  if v_order.status in ('completed', 'cancelled') then raise exception 'order is already closed'; end if;
  if (v_order.status = 'new' and p_status not in ('confirmed', 'cancelled'))
    or (v_order.status = 'confirmed' and p_status not in ('processing', 'cancelled'))
    or (v_order.status = 'processing' and p_status not in ('completed', 'cancelled')) then
    raise exception 'invalid order status transition';
  end if;
  if p_status = 'cancelled' then
    update public.products p
    set stock = p.stock + oi.quantity
    from public.order_items oi
    where oi.order_id = p_order_id and oi.product_id = p.id;
  end if;
  update public.orders set status = p_status where id = p_order_id;
end;
$$;

-- Public API rate limiter used only by the public-catalog Edge Function.
create table if not exists public.api_rate_limits (
  key_hash text primary key,
  window_started_at timestamptz not null default now(),
  hit_count integer not null default 0
);

create or replace function public.consume_public_api_limit(
  p_key_hash text,
  p_max_hits integer default 120,
  p_window_seconds integer default 60
)
returns boolean
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_allowed boolean;
begin
  if p_key_hash is null or char_length(p_key_hash) <> 64
    or p_max_hits < 1 or p_max_hits > 1000
    or p_window_seconds < 1 or p_window_seconds > 3600 then
    raise exception 'invalid rate limit arguments';
  end if;

  perform pg_advisory_xact_lock(hashtext(p_key_hash));
  insert into public.api_rate_limits(key_hash, window_started_at, hit_count)
  values (p_key_hash, now(), 0)
  on conflict (key_hash) do nothing;

  update public.api_rate_limits
  set window_started_at = case
        when window_started_at < now() - make_interval(secs => p_window_seconds) then now()
        else window_started_at
      end,
      hit_count = case
        when window_started_at < now() - make_interval(secs => p_window_seconds) then 1
        else hit_count + 1
      end
  where key_hash = p_key_hash
  returning hit_count <= p_max_hits into v_allowed;

  return coalesce(v_allowed, false);
end;
$$;

create or replace function public.prune_api_rate_limits()
returns integer
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_deleted integer;
begin
  delete from public.api_rate_limits
  where window_started_at < now() - interval '24 hours';
  get diagnostics v_deleted = row_count;
  return v_deleted;
end;
$$;

-- -----------------------------------------------------------------------------
-- Row Level Security
-- -----------------------------------------------------------------------------

alter table public.profiles enable row level security;
alter table public.boutiques enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.favorites enable row level security;
alter table public.order_rate_limits enable row level security;
alter table public.api_rate_limits enable row level security;

-- Profiles: users can read their own row; admin can read all. The browser may
-- update full_name only, never role/is_blocked/phone.
drop policy if exists profiles_read_self_or_admin on public.profiles;
create policy profiles_read_self_or_admin on public.profiles
for select to authenticated
using (id = auth.uid() or public.is_admin());

drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles
for update to authenticated
using (id = auth.uid() and not is_blocked)
with check (id = auth.uid() and not is_blocked);

-- Public catalogue only exposes active stores and active products.
drop policy if exists boutiques_public_or_owner on public.boutiques;
create policy boutiques_public_or_owner on public.boutiques
for select to anon, authenticated
using ((is_active = true and verified = true) or owner_id = auth.uid() or public.is_admin());

drop policy if exists boutiques_insert_owner on public.boutiques;
create policy boutiques_insert_owner on public.boutiques
for insert to authenticated
with check (owner_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller' and p.is_blocked = false));

drop policy if exists boutiques_update_owner_or_admin on public.boutiques;
create policy boutiques_update_owner_or_admin on public.boutiques
for update to authenticated
using (public.is_seller_owner(id) or public.is_admin())
with check (public.is_seller_owner(id) or public.is_admin());

drop policy if exists products_public_or_owner on public.products;
create policy products_public_or_owner on public.products
for select to anon, authenticated
using (
  (is_active = true and exists (select 1 from public.boutiques b where b.id = boutique_id and b.is_active = true and b.verified = true))
  or public.is_seller_owner(boutique_id)
  or public.is_admin()
);

drop policy if exists products_insert_owner on public.products;
create policy products_insert_owner on public.products
for insert to authenticated
with check (public.is_seller_owner(boutique_id));

drop policy if exists products_update_owner_or_admin on public.products;
create policy products_update_owner_or_admin on public.products
for update to authenticated
using (public.is_seller_owner(boutique_id) or public.is_admin())
with check (public.is_seller_owner(boutique_id) or public.is_admin());

drop policy if exists products_delete_owner_or_admin on public.products;
create policy products_delete_owner_or_admin on public.products
for delete to authenticated
using (public.is_seller_owner(boutique_id) or public.is_admin());

-- Orders are readable only by the buyer, owner of the store, or admin.
drop policy if exists orders_read_participants on public.orders;
create policy orders_read_participants on public.orders
for select to authenticated
using (buyer_id = auth.uid() or public.is_seller_owner(boutique_id) or public.is_admin());

drop policy if exists order_items_read_participants on public.order_items;
create policy order_items_read_participants on public.order_items
for select to authenticated
using (exists (
  select 1 from public.orders o
  where o.id = order_id
    and (o.buyer_id = auth.uid() or public.is_seller_owner(o.boutique_id) or public.is_admin())
));

-- Favourites always belong to the signed-in user.
drop policy if exists favorites_read_own on public.favorites;
create policy favorites_read_own on public.favorites
for select to authenticated using (user_id = auth.uid());
drop policy if exists favorites_insert_own on public.favorites;
create policy favorites_insert_own on public.favorites
for insert to authenticated with check (user_id = auth.uid());
drop policy if exists favorites_delete_own on public.favorites;
create policy favorites_delete_own on public.favorites
for delete to authenticated using (user_id = auth.uid());

-- order_rate_limits has no direct browser access.

-- -----------------------------------------------------------------------------
-- Explicit grants: browser roles get only the operations used by the MVP.
-- -----------------------------------------------------------------------------

grant usage on schema public to anon, authenticated;
-- Reset default Supabase grants first; the MVP re-opens only explicitly needed
-- operations below. This avoids silently inheriting broad project defaults.
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;
revoke select on public.boutiques, public.products from anon;
grant select on public.boutiques, public.products to authenticated;
grant select on public.profiles to authenticated;
revoke update on public.profiles from anon, authenticated;
grant update (full_name) on public.profiles to authenticated;
grant insert (owner_id, name, description, category, city, phone, cover_url) on public.boutiques to authenticated;
revoke update on public.boutiques from authenticated;
grant update (name, description, category, city, phone, cover_url, is_active) on public.boutiques to authenticated;
grant insert (boutique_id, title, description, category, price, old_price, image_url, sizes, colors, stock, is_active) on public.products to authenticated;
grant update (title, description, category, price, old_price, image_url, sizes, colors, stock, is_active) on public.products to authenticated;
grant delete on public.products to authenticated;
grant select on public.orders, public.order_items to authenticated;
grant select, delete on public.favorites to authenticated;
grant insert (user_id, product_id) on public.favorites to authenticated;
revoke all on public.order_rate_limits from anon, authenticated;
revoke all on public.api_rate_limits from anon, authenticated;

revoke all on function public.is_admin() from public;
revoke all on function public.is_seller_owner(uuid) from public;
revoke all on function public.handle_new_auth_user() from public;
revoke all on function public.set_user_role(uuid, text) from public;
revoke all on function public.set_user_blocked(uuid, boolean) from public;
revoke all on function public.place_cart_orders(jsonb, text) from public;
revoke all on function public.set_boutique_verified(uuid, boolean) from public;
revoke all on function public.set_order_status(uuid, text) from public;
revoke all on function public.consume_public_api_limit(text, integer, integer) from public;
revoke all on function public.prune_api_rate_limits() from public;
grant execute on function public.is_admin() to anon, authenticated;
grant execute on function public.is_seller_owner(uuid) to anon, authenticated;
grant execute on function public.set_user_role(uuid, text) to authenticated;
grant execute on function public.set_user_blocked(uuid, boolean) to authenticated;
grant execute on function public.place_cart_orders(jsonb, text) to authenticated;
grant execute on function public.set_boutique_verified(uuid, boolean) to authenticated;
grant execute on function public.set_order_status(uuid, text) to authenticated;
grant execute on function public.consume_public_api_limit(text, integer, integer) to service_role;
grant execute on function public.prune_api_rate_limits() to service_role;

-- -----------------------------------------------------------------------------
-- One-time bootstrap: after the owner has registered using phone OTP, run a
-- trusted SQL statement (replace the phone) to assign the first admin:
-- update public.profiles set role = 'admin' where phone = '+79990000000';
-- Do not add this statement to browser JavaScript or expose service credentials.
-- -----------------------------------------------------------------------------
