import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const APP_ORIGIN = Deno.env.get('APP_ORIGIN') || '*';
const corsHeaders = {
  'Access-Control-Allow-Origin': APP_ORIGIN,
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Vary': 'Origin',
  'Content-Type': 'application/json; charset=utf-8',
};

function json(status: number, body: unknown, extra: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, ...extra },
  });
}

async function sha256(input: string): Promise<string> {
  const bytes = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest)).map((value) => value.toString(16).padStart(2, '0')).join('');
}

function requestIp(request: Request): string | null {
  // These headers are populated by the platform/proxy. Do not accept a custom
  // x-forwarded-for header from arbitrary clients on a self-hosted deployment.
  const direct = request.headers.get('cf-connecting-ip') || request.headers.get('x-real-ip');
  if (direct) return direct.trim();
  const forwarded = request.headers.get('x-forwarded-for');
  return forwarded?.split(',')[0]?.trim() || null;
}

Deno.serve(async (request: Request) => {
  const origin = request.headers.get('origin');
  if (APP_ORIGIN !== '*' && origin && origin !== APP_ORIGIN) return json(403, { error: 'origin_not_allowed' });
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') return json(405, { error: 'method_not_allowed' });

  const ip = requestIp(request);
  if (!ip) return json(400, { error: 'client_ip_unavailable' });

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const salt = Deno.env.get('RATE_LIMIT_SALT');
  if (!supabaseUrl || !serviceKey || !salt) {
    // Fail closed. Public catalogue is not served if rate limiting is not ready.
    return json(503, { error: 'catalog_service_not_configured' });
  }

  const db = createClient(supabaseUrl, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  try {
    const keyHash = await sha256(`${salt}:${ip}:public-catalog`);
    const { data: allowed, error: limitError } = await db.rpc('consume_public_api_limit', {
      p_key_hash: keyHash,
      p_max_hits: 120,
      p_window_seconds: 60,
    });
    if (limitError) return json(503, { error: 'rate_limit_unavailable' });
    if (allowed !== true) return json(429, { error: 'rate_limit_exceeded' }, { 'Retry-After': '60' });

    const body = await request.json().catch(() => ({}));
    const requestedLimit = Number(body?.limit || 48);
    const limit = Math.max(1, Math.min(48, Number.isFinite(requestedLimit) ? Math.floor(requestedLimit) : 48));

    const [productsResult, boutiquesResult] = await Promise.all([
      db.from('products')
        .select('id, boutique_id, title, description, category, price, old_price, image_url, sizes, colors, stock, is_active, created_at, boutiques!inner(name, cover_url)')
        .eq('is_active', true)
        .eq('boutiques.is_active', true)
        .eq('boutiques.verified', true)
        .gt('stock', 0)
        .order('created_at', { ascending: false })
        .limit(limit),
      db.from('boutiques')
        .select('id, name, description, city, category, cover_url, verified, is_active')
        .eq('is_active', true)
        .eq('verified', true)
        .order('name')
        .limit(36),
    ]);

    if (productsResult.error || boutiquesResult.error) {
      return json(500, { error: 'catalog_query_failed' });
    }

    return json(200, {
      products: productsResult.data || [],
      boutiques: boutiquesResult.data || [],
    }, { 'Cache-Control': 'public, max-age=20, s-maxage=40' });
  } catch {
    return json(500, { error: 'catalog_unavailable' });
  }
});
